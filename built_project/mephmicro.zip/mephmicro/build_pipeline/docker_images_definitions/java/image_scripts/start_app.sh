/data/join_jars.sh
JAVA_OPTS="-Dspring.profiles.active=$SPRING_PROFILES_ACTIVE"
java -jar $JAVA_OPTS /data/$FINAL_JAR
