#!/bin/bash
export K8S_ENV_NAMESPACE_POSTFIX="-integration"

export RESTAPI_K8S_DOMAIN_NAME=meph.com
export RESTAPI_K8S_DOMAIN_NAME_PREFIX=mephmicro.integration.
export RESTAPI_K8S_DOMAIN_NAME_POSTFIX=
