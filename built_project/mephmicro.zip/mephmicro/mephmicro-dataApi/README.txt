test

Nos hemos inventado un MailSenderDataServiceTest para evitar los problemas de testear en h2 las sequences.

Mock

Creamos profiles para activar mocks a todos los niveles.

bbdd

Incorporo de momento solo la configuracion de ci en main/resources para que funcione la inclusion en otros modulos.
Hago lo mismo con las configs de flyway