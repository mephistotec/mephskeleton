#!/usr/bin/env bash
export DOCKER_HOST=localhost:2375
export LINUXWONWIN=true

. ./opt_devcasa.sh

