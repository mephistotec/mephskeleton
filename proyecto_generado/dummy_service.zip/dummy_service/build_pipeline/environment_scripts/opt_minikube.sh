function get_registry_login_command
{
    return "docker login -u admin -p admin https://registry.meph.com"
}