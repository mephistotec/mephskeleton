#!/usr/bin/env bash

export ONLY_DESCRIPTORS="yes"

