export   MAVEN_SETTINGS="--settings /Users/dani/wrk/desarrollo/svn_reps/20170220_mango/mvn_config/settings.xml"
