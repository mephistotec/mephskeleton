#!/usr/bin/env bash
docker run -d -p 49160:22 -p 49161:1521 mngpatilleditor_bbddtest
