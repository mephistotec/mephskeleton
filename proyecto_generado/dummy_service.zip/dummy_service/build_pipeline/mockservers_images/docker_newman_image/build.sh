#!/usr/bin/env bash
docker build --tag newman_mng .
