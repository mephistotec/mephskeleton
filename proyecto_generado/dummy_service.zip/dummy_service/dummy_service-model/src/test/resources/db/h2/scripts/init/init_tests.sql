CREATE SCHEMA IF NOT EXISTS "public";

create schema if not exists mngbd;  
